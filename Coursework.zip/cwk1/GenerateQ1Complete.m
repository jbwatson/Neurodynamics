function GenerateQ1Complete( prob, simTime )

GenerateQ1Network(prob);
PlotMatricesQ1(prob);
Run2L(prob, simTime);



end

