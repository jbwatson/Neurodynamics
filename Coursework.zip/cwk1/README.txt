
-----------------
QUESTION 1
-----------------
Question 1 is run by GenerateQ1Complete( n, 1000 ) where n is the desired
probability.

The graphs are then: 

- Q1a-prob__.fig where the blank is the probability for Q1a
- Q1b-prob__.fig where the blank is the probability for Q1b
- Q1c-prob__.fig where the blank is the probability for Q1c

------------------
QUESTION 2
------------------

Question2 is run by calling GenerateQ2Complete().

The 20 Networks have been created and modeled.

The generated graph is Q2.fig

WARNING: Due to an error in the 'getComplexity' function the grpah is wrong
